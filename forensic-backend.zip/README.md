# 🔍 Forensic Backend
API ringan untuk kebutuhan digital forensic modern.

## Developer
YudhaAfgani X Ai

## Cara Jalankan (Lokal)
```bash
npm install
npm start
```

## Deploy ke Railway
1. Upload folder ini ke GitHub
2. Buka [Railway.app](https://railway.app)
3. Deploy from GitHub
4. Selesai 🚀
