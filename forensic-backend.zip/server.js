const express = require("express");
const cors = require("cors");
const axios = require("axios");
const app = express();

app.use(cors());
app.use(express.json());

// Root route
app.get("/", (req, res) => {
  res.json({
    status: "✅ Server aktif",
    author: "YudhaAfgani X Ai",
    version: "1.0.0",
  });
});

// Contoh API digital forensic (dummy data)
app.post("/analyze", async (req, res) => {
  const { ip } = req.body;
  if (!ip) return res.status(400).json({ error: "IP address required" });

  // Contoh analisis sederhana (mockup)
  const result = {
    ip,
    location: "Unknown",
    riskScore: Math.floor(Math.random() * 100),
    timestamp: new Date().toISOString(),
  };

  res.json({ analysis: result });
});

// Jalankan server
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`🚀 Server berjalan di port ${port}`));
